<style>
.bck{
background:#08C;
}
.bckk{
background:#fff;
text-shadow:none;
}
.back{
background:#cdcdcd;
text-shadow:none;
}
</style>

						<div class="list_menu">
								 <ul class="accordion" id="accordion-5">
										<li class="active">
											<i class="icon-chevron-right"></i> Dashboard
										</li>
										<li>
											<a href="addspeciality.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>Add Specification</a>
										</li>
										<li>
											<a href="cities.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>Add Cities</a>
										</li>
										<!--<li>
											<a href="doctor.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>Add Doctor</a>
										</li>
										<li>
											<a href="addimage.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>Add Small Images</a>
										</li>-->
										<li>
											<a href="manager.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>Add Manager</a>
										</li>
										<li>
											<a href="agent.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>Add Agent</a>
										</li>
										<li class="bck"><a href="#" style="color:#fff; text-shadow:none;">Reports</a>
												<ul>
														<li>
														<a href="viewfeedreport.php" class="back">View Feedback Report</a>
														</li>
														<li>
														<a href="viewappointreport.php" class="back">View Appointment Report</a>
														</li>														
												</ul>
										</li>
										<li>
											<a href="adminlogout.php"><i class="icon-chevron-right"><img src="image/1.png" /></i>Log Out</a>
										</li>
						  </ul>
						</div>
				